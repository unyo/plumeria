<?php

// The file
$filename = 'ocean.jpg';
$percent = 0.5;

// Content type
//header('Content-type: image/jpeg');

// Get new dimensions
list($width, $height) = getimagesize($filename);
$new_width = 5;
$new_height = 5;

// Resample
$image_p = imagecreatetruecolor($new_width, $new_height);
$image = imagecreatefromjpeg($filename);
imagecopyresampled($image_p, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);

// Output
//imagejpeg($image_p, null, 100);

$rgb = ImageColorAt($image_p, 1, 1);
$r = ($rgb >> 16) & 0xFF;
$g = ($rgb >> 8) & 0xFF;
$b = $rgb & 0xFF;
echo $r;
?>