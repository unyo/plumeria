<?php

// The file
$filename = 'ocean.jpg';

// Get new dimensions
list($width, $height) = getimagesize($filename);
$new_width = 5;
$new_height = 5;

// Resample
$image_p = imagecreatetruecolor($new_width, $new_height);
$image = imagecreatefromjpeg($filename);
imagecopyresampled($image_p, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);

$filename2 = 'ocean6.jpg';
list($width2, $height2) = getimagesize($filename2);

$image_p2 = imagecreatetruecolor($new_width, $new_height);
$image2 = imagecreatefromjpeg($filename2);
imagecopyresampled($image_p2, $image2, 0, 0, 0, 0, $new_width, $new_height, $width2, $height2);

for ($i = 0; $i < $new_width; $i++) {
	for ($i2 = 0; $i2 < $new_height; $i2++) {
		$rgb1 = ImageColorAt($image_p, $i, $i2);
		$rgb2 = ImageColorAt($image_p2, $i, $i2);
		$r = ($rgb1 >> 16) & 0xFF;
		$g = ($rgb1 >> 8) & 0xFF;
		$b = $rgb1 & 0xFF;
		
		$r2 = ($rgb2 >> 16) & 0xFF;
		$g2 = ($rgb2 >> 8) & 0xFF;
		$b2 = $rgb2 & 0xFF;
		
		$rd = abs($r-$r2);
		$bd = abs($b-$b2);
		$gd = abs($g-$g2);
		
		echo '('.$rd.'-'.$gd.'-'.$bd.')<br />';
		if ($r>$g and $g>$b) { $bd*=4; $gd*=2; }
		if ($r>$b and $b>$g) { $gd*=4; $bd*=2; }
		if ($g>$b and $b>$r) { $rd*=4; $bd*=2; }
		if ($g>$r and $r>$b) { $bd*=4; $rd*=2; }
		if ($b>$r and $r>$g) { $gd*=4; $rd*=2; }
		if ($b>$g and $g>$r) { $rd*=4; $gd*=2; }
		echo $rd.'-'.$gd.'-'.$bd.'<br />';
		$w++;
		$zr+=$rd;
		$zg+=$gd;
		$zb+=$bd;
	}
}

echo '<br /><br />';
echo $zr.'-'.(100-round((($zr/$w)/255)*100)).'% similar in RED<br />';
echo $zg.'-'.(100-round((($zg/$w)/255)*100)).'% similar in GREEN<br />';
echo $zb.'-'.(100-round((($zb/$w)/255)*100)).'% similar in BLUE<br />';


?>