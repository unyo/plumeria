<?php

$file = $_SERVER['argv'][0];
$size = $_SERVER['argv'][1];

echo $file.'::';
		
list($width, $height) = getimagesize($file);
		
	$image_p = imagecreatetruecolor($size, $size);
	$image = imagecreatefromjpeg($file);
	imagecopyresampled($image_p, $image, 0, 0, 0, 0, $size, $size, $width, $height);
		
	for ($i = 0; $i < $size; $i++) {
		for ($i2 = 0; $i2 < $size; $i2++) {
			$rgb1 = ImageColorAt($image_p, $i, $i2);
			$r = ($rgb1 >> 16) & 0xFF;
			$g = ($rgb1 >> 8) & 0xFF;
			$b = $rgb1 & 0xFF;
			echo $r.'-'.$g.'-'.$b.' ';
			}
		}
      echo "\r\n";

?>