<?php

if($argc==1)
{
   echo "Compares an image to RGB signitures stored in the database.\r\n\r\n";
	echo "Usage: imgcm (image) [pixels] [dbfile] [matches]\r\n";
   echo "   img      Filename of the image to compare to the database.\r\n";
   echo "   pixels   The number of pixels to resize the image to. Determines how fine\r\n";
   echo "            matching is, and also the size of the database. For instance, a\r\n";
   echo "            value of 2 gives a 2x2 image, so 4 RGB values per image. Default 3.\r\n";
   echo "   dbfile   File to store the database in. Default 'plumeria.db'\r\n";
   echo "   matches  Number of matches to return. Default 25.\r\n";
	exit;
}

$ifile = $_SERVER['argv'][1];
$size = $_SERVER['argv'][2];
$dbfile = $_SERVER['argv'][3];
$num_match = $_SERVER['argv'][4];

if (empty($size)) $size=3;
if (empty($dbfile)) $dbfile='plumeria.db';
if (empty($num_match)) $num_match=25;

$ohtml = fopen('output.html','w') or die('ERROR: Open output.html failed');

echo '==='.$ifile."===\r\n";
fwrite($ohtml,'<img src="file:///'.$ifile.'" /><br />');

$dbarr = file($dbfile);

$somearray=array_fill(0,$num_match,'');

list($width, $height) = getimagesize($ifile);
		
	$image_p = imagecreatetruecolor($size, $size);
	$image = imagecreatefromjpeg($ifile);
	imagecopyresampled($image_p, $image, 0, 0, 0, 0, $size, $size, $width, $height);

foreach ($dbarr as $dbline) {
   $dbline=rtrim($dbline);
   $fnarr=explode('::',$dbline,2);
   $pixarr=explode(' ',$fnarr[1]);
   $w=0;
   $x=0;
   $zr=0;
   $zg=0;
   $zb=0;
   for ($i = 0; $i < $size; $i++) {
      for ($i2 = 0; $i2 < $size; $i2++) {
         $rgb1 = ImageColorAt($image_p, $i, $i2);
         $r = ($rgb1 >> 16) & 0xFF;
         $g = ($rgb1 >> 8) & 0xFF;
         $b = $rgb1 & 0xFF;
		
         $rgb2=explode('-',$pixarr[$x]);
         $r2=$rgb2[0];
         $g2=$rgb2[1];
         $b2=$rgb2[2];
      
         $rd = abs($r-$r2);
         $bd = abs($b-$b2);
         $gd = abs($g-$g2);
         
         if ($r>$g and $g>$b) { $bd*=3; $gd*=2; }
         if ($r>$b and $b>$g) { $gd*=3; $bd*=2; }
         if ($g>$b and $b>$r) { $rd*=3; $bd*=2; }
         if ($g>$r and $r>$b) { $bd*=3; $rd*=2; }
         if ($b>$r and $r>$g) { $gd*=3; $rd*=2; }
         if ($b>$g and $g>$r) { $rd*=3; $gd*=2; }
         
         
         $w++;
         $zr+=$rd;
         $zg+=$gd;
         $zb+=$bd;
      $x++;
      }
   }
   $urr=(100-round((((($zr+$zg+$zb)/$w)/255)/3)*100));
   $lulz=$fnarr[0];
   array_push($somearray, array($urr,$lulz));
   rsort($somearray);
   array_pop($somearray);
   }

rsort($somearray);
for ($nx=0;$nx<$num_match;$nx++) {
   echo $somearray[$nx][0].'% - '.$somearray[$nx][1]."\r\n";
   fwrite($ohtml,$somearray[$nx][0].'% - '.'<img src="file:///'.$somearray[$nx][1].'" />'."<br />\r\n");
   }

fclose($ohtml);
   
?>