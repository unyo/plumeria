<?php

if($argc==1)
{
   echo "Scans directory of jpeg's and adds the RGB signiture to database.\r\n\r\n";
	echo "Usage: imgdb (image) [pixels] [dbfile]\r\n";
   echo "   img    Full pathname of an image located in the folder to scan.\r\n";
   echo "          ie 'C:\unsorted\anyjpg.jpg' will scan all images in 'C:\unsorted'\r\n";
   echo "   pixels The number of pixels to resize the image to. Determines how fine\r\n";
   echo "          matching is, and also the size of the database. For instance, a\r\n";
   echo "          value of 2 gives a 2x2 image, so 4 RGB values per image. Default 3.\r\n";
   echo "   dbfile File to store the database in. Default 'plumeria.db'.\r\n";
	exit;
}

$drr = $_SERVER['argv'][1];
$size = $_SERVER['argv'][2];
$dbf = $_SERVER['argv'][3];

if (empty($size)) $size=3;
if (empty($dbf)) $dbf='plumeria.db';

$realdrr = dirname($drr).'/';

$db_txt = fopen($dbf,'a') or die('ERROR: Database open failed');

$handle = opendir($realdrr); 
while (false !== ($fname = readdir($handle))) {

if (strpos($fname,'.jpg') or strpos($fname,'.jpeg')) {

   $tmp = '';

   $fname = $realdrr.$fname;
	echo $fname.'::';
		
	list($width, $height) = getimagesize($fname);
   //echo $width.$height;
		
	$image_p = imagecreatetruecolor($size, $size);
	$image = imagecreatefromjpeg($fname);
	imagecopyresampled($image_p, $image, 0, 0, 0, 0, $size, $size, $width, $height);
   
	for ($i = 0; $i < $size; $i++) {
		for ($i2 = 0; $i2 < $size; $i2++) {
			$rgb1 = ImageColorAt($image_p, $i, $i2);
			$r = ($rgb1 >> 16) & 0xFF;
			$g = ($rgb1 >> 8) & 0xFF;
			$b = $rgb1 & 0xFF;
         
         if (max($r,$g,$b)==min($r,$g,$b)) {$h=0;}
         elseif ((max($r,$g,$b)==$r) and ($g>=$b)) {$h=(60*(($g-$b)/(max($r,$g,$b)-min($r,$g,$b))));}
         elseif ((max($r,$g,$b)==$r) and ($g<$b)) {$h=(60*(($g-$b)/(max($r,$g,$b)-min($r,$g,$b))))+360;}
         elseif (max($r,$g,$b)==$g) {$h=(60*(($b-$r)/(max($r,$g,$b)-min($r,$g,$b))))+120;}
         elseif (max($r,$g,$b)==$b) {$h=(60*(($g-$r)/(max($r,$g,$b)-min($r,$g,$b))))+240;}
         $h = round($h);
         $s = (max($r,$g,$b)>0)?(round(((1-(min($r,$g,$b)/max($r,$g,$b)))*100))):0;
         $v = max($r,$g,$b);
         
			echo $h.'-'.$s.'-'.$v.' ';
         $tmp .= $h.'-'.$s.'-'.$v.' ';
         flush();
			}
		}
      echo "\r\n";
      fwrite($db_txt,$fname.'::'.$tmp."\r\n");
	}
}

fclose($db_txt);

?>