<?php

if($argc==1)
{
   echo "Compares an image to RGB signitures stored in the database.\r\n\r\n";
	echo "Usage: imgcm (image) [pixels] [dbfile] [matches]\r\n";
   echo "   img      Filename of the image to compare to the database.\r\n";
   echo "   pixels   The number of pixels to resize the image to. Determines how fine\r\n";
   echo "            matching is, and also the size of the database. For instance, a\r\n";
   echo "            value of 2 gives a 2x2 image, so 4 RGB values per image. Default 3.\r\n";
   echo "   dbfile   File to store the database in. Default 'plumeria.db'\r\n";
   echo "   matches  Number of matches to return. Default 25.\r\n";
	exit;
}

$ifile = $_SERVER['argv'][1];
$size = $_SERVER['argv'][2];
$dbfile = $_SERVER['argv'][3];
$num_match = $_SERVER['argv'][4];

if (empty($size)) $size=3;
if (empty($dbfile)) $dbfile='plumeria.db';
if (empty($num_match)) $num_match=25;

$ohtml = fopen('output.html','w') or die('ERROR: Open output.html failed');

echo '==='.$ifile."===\r\n";
fwrite($ohtml,'<img src="file:///'.$ifile.'" /><br />');

$dbarr = file($dbfile);

$somearray=array_fill(0,$num_match,'');

list($width, $height) = getimagesize($ifile);
		
	$image_p = imagecreatetruecolor($size, $size);
	$image = imagecreatefromjpeg($ifile);
	imagecopyresampled($image_p, $image, 0, 0, 0, 0, $size, $size, $width, $height);

foreach ($dbarr as $dbline) {
   $dbline=rtrim($dbline);
   $fnarr=explode('::',$dbline,2);
   $pixarr=explode(' ',$fnarr[1]);
   $w=0;
   $x=0;
   $zh=0;
   $zs=0;
   $zv=0;
   for ($i = 0; $i < $size; $i++) {
      for ($i2 = 0; $i2 < $size; $i2++) {
         $rgb1 = ImageColorAt($image_p, $i, $i2);
         $r = ($rgb1 >> 16) & 0xFF;
         $g = ($rgb1 >> 8) & 0xFF;
         $b = $rgb1 & 0xFF;
         
         if (max($r,$g,$b)==min($r,$g,$b)) {$h=0;}
         elseif ((max($r,$g,$b)==$r) and ($g>=$b)) {$h=(60*(($g-$b)/(max($r,$g,$b)-min($r,$g,$b))));}
         elseif ((max($r,$g,$b)==$r) and ($g<$b)) {$h=(60*(($g-$b)/(max($r,$g,$b)-min($r,$g,$b))))+360;}
         elseif (max($r,$g,$b)==$g) {$h=(60*(($b-$r)/(max($r,$g,$b)-min($r,$g,$b))))+120;}
         elseif (max($r,$g,$b)==$b) {$h=(60*(($g-$r)/(max($r,$g,$b)-min($r,$g,$b))))+240;}
         $h = round($h);
         $s = (max($r,$g,$b)>0)?(round(((1-(min($r,$g,$b)/max($r,$g,$b)))*100))):0;
         $v = max($r,$g,$b);
         
         //echo $h.'.'.$s.'.'.$v."\r\n";
		
         $rgb2=explode('-',$pixarr[$x]);
         $h2=$rgb2[0];
         $s2=$rgb2[1];
         $v2=$rgb2[2];
         
         //echo $h2.'.'.$s2.'.'.$v2."\r\n";
         
         $hd = abs($h-$h2);
			if ($hd>180) $hd=(180-($hd-180));
         $sd = abs($s-$s2);
         $vd = abs($v-$v2);         
         
         $w++;
         $zh+=$hd;
         $zs+=$sd;
         $zv+=$vd;
      $x++;
      }
   }
   $urr=(100-round(((($zh/10)+($zs/100)+($zv/50))/$w)));
   echo $urr.'-'.$fnarr[0].'-'.$zh.'-'.$zs.'-'.$zv.'-'."\r\n";
   $lulz=$fnarr[0];
   array_push($somearray, array($urr,$lulz));
   rsort($somearray);
   array_pop($somearray);
   }

rsort($somearray);
for ($nx=0;$nx<$num_match;$nx++) {
   echo $somearray[$nx][0].'% - '.$somearray[$nx][1]."\r\n";
   fwrite($ohtml,$somearray[$nx][0].'% - '.'<img src="file:///'.$somearray[$nx][1].'" />'."<br />\r\n");
   }

fclose($ohtml);
   
?>