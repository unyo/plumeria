<?php
$desu = file_get_contents($_SERVER['argv'][1]);
$desudesu = bin2hex($desu);
if (!(strpos($desudesu,'377abcaf271c0002')===false) or (strpos($desudesu,'526172211a0700cf907300000d00000000000000'))) {
	echo "ARCHIVE FOUND in ".basename($_SERVER['argv'][1])."\r\n";
	}

?>